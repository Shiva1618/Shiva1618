package com.codingwithjks.weatherapp.Model

data class Weather(
    val description:String = "",
    val icon:String = ""
)
