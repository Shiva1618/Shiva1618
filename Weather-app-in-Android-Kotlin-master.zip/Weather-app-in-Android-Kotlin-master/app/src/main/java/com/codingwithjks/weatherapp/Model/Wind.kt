package com.codingwithjks.weatherapp.Model

data class Wind (
    val speed:Float =0.0f,
    val deg:Int = 0
){

}
