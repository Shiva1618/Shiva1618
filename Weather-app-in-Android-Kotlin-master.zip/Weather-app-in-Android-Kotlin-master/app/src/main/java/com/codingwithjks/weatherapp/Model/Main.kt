package com.codingwithjks.weatherapp.Model

data class Main(
    val temp:Double = 0.0,
    val humidity:Int = 0
) {

}
