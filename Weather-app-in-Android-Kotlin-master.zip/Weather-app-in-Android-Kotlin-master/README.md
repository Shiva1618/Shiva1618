# Weather Application in Android Kotlin

In this project, we are going to make a weather application , with the help of dagger-hilt, retofit,coroutines,flow and channel. I have used openweather free api to make network request...

<p align="center">
<img src="app/src/main/res/drawable/one.png" height=300px/>
<img src="app/src/main/res/drawable/two.png" height=300px/>
</p>
