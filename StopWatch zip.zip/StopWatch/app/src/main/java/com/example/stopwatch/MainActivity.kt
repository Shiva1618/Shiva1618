import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.stopwatch.R
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var tvTimer: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnReset: Button

    private var isRunning = false
    private var elapsedTime = 0L
    private var startTime = 0L
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTimer = findViewById(R.id.tv_timer)
        btnStart = findViewById(R.id.btn_start)
        btnStop = findViewById(R.id.btn_stop)
        btnReset = findViewById(R.id.btn_reset)

        btnStart.setOnClickListener { startTimer() }
        btnStop.setOnClickListener { stopTimer() }
        btnReset.setOnClickListener { resetTimer() }
    }

    private fun startTimer() {
        if (isRunning) return

        isRunning = true
        startTime = SystemClock.elapsedRealtime() - elapsedTime
        job = CoroutineScope(Dispatchers.Main).launch {
            while (isRunning) {
                elapsedTime = SystemClock.elapsedRealtime() - startTime
                tvTimer.text = formatTime(elapsedTime)
                delay(100)
            }
        }
    }

    private fun stopTimer() {
        isRunning = false
        job?.cancel()
    }

    private fun resetTimer() {
        stopTimer()
        elapsedTime = 0L
        tvTimer.text = "00:00:00"
    }

    private fun formatTime(milliseconds: Long): String {
        val seconds = milliseconds / 1000 % 60
        val minutes = milliseconds / 1000 / 60 % 60
        val hours = milliseconds / 1000 / 60 / 60
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }
}
