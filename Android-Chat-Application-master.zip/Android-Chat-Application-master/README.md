# Chatproject
Android Studio Chat application using Kotlin


# Description 
Using Basic components and RecyclerView<br>
Login function using Firebase Authentication <br>
Chatting function using Firebase realtimedatabase <br>


# Function
Sign up : make your account to use application. ID format is used e-mail format<br>
Log in : using firebase Authentication<br>
Log out: log out by clicking log out button in menu<br>
Showing all members : showing all members in Firebase by using Rechclerview<br>
Chatting in the room : after click member button, you can enter the room, and you can chat in chat room<br>
Chat in realtime : using realtime database in Firebase

## More Detail : ppt
