package PGR208.exam.edamamapp

import PGR208.exam.edamamapp.models.Hit
import PGR208.exam.edamamapp.models.Recipe
import PGR208.exam.edamamapp.models.RecipeResponse

object RecipeResponseHitsList {
    val recipeResponseHitsList = mutableListOf<Hit>()
}