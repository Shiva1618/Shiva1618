package PGR208.exam.edamamapp

import PGR208.exam.edamamapp.Database_searchHistory.SearchHistoryEntity

object SearchHistoryEntityList {
    var searchHistoryEntityList = mutableListOf<SearchHistoryEntity>()
}