package PGR208.exam.edamamapp.models

import java.io.Serializable

data class Next(
    val href: String,
    val title: String
): Serializable
