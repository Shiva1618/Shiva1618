package com.example.loginapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RegisterActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        // Initialize UI elements
        val etUsername = findViewById<EditText>(R.id.Username_input)
        val etEmail = findViewById<EditText>(R.id.Email_input)
        val etPassword = findViewById<EditText>(R.id.password_input)
        val etConfirmPassword = findViewById<EditText>(R.id.confirmpassword_input)
        val etRegister = findViewById<Button>(R.id.resgister_btn)

        etRegister.setOnClickListener {
            val login = etRegister.text.toString()
            val password = etPassword.text.toString()
            val confirmPassword = etConfirmPassword.text.toString()

            // Validate input
            when {
                login.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() -> {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                }
                password != confirmPassword -> {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Toast.makeText(this, "Sign Up Successful", Toast.LENGTH_SHORT).show()
                    // Add additional logic here (e.g., save user data to a database or server)

    }
}}}}