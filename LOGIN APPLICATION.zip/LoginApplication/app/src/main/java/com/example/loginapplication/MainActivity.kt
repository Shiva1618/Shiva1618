package com.example.loginapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {


    lateinit var loginBtn : Button
    lateinit var btn_register : Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        loginBtn = findViewById(R.id.login_btn)
        btn_register = findViewById(R.id.btn_register_b)

        loginBtn.setOnClickListener {

            val intent: Intent = Intent(
                this@MainActivity,
                HomeScreen::class.java
            )
            startActivity(intent)


        }
        btn_register.setOnClickListener {

            val intent: Intent = Intent(
                this@MainActivity,
                RegisterActivity::class.java
            )
            startActivity(intent)
        }


    }
}