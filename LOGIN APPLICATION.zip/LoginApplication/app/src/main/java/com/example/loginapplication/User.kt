package com.example.loginapplication

data class User(var name: String,var lastMessage : String,var lastMsgTime : String,
                var phoneNo : String, var country : String, var imageId : Int)
