package com.example.loginapplication

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputBinding
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.loginapplication.activities.UserActivity
import com.example.loginapplication.databinding.ActivityHomeScreen2Binding
import com.example.loginapplication.databinding.ActivityMainBinding
import com.example.loginapplication.databinding.FragmentHomeBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeScreen : AppCompatActivity() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var userArrayList: ArrayList<User>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.fragment_home)
        binding = FragmentHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageId = intArrayOf(

            R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d,R.drawable.e,
            R.drawable.f,R.drawable.g,R.drawable.h,R.drawable.face,R.drawable.g,R.drawable.h,R.drawable.face
        )
        val name = arrayOf(
            "Christopher",
            "Joe",
            "Mice",
            "Tom",
            "Kraig",
            "Toa",
            "Alex",
            "Root",
            "Mike",
            "Cruise",
            "Sam",
            "Sam"
        )


        val lastMessage = arrayOf(
            "Heyy", "Hiii","Yup", "Hello","Yes","What","Why","bkj",
            "Where", "Let it go", "In a meeting", "Call you back"
        )

        val lastmsgTime = arrayOf(

            "7.00pm", "8.45pm", "2.54pm","5.09pm","1.00pm","2.32pm",
            "3.43pm","1.32pm","3.42pm","4.56am","3.23am","9.21am"
        )

        val phoneNo = arrayOf(
            "637887289","346878923","579387890","835979387","763896421","489036784","58368780","846780760","783686305","5795967340760","875465054","746266764","748642607"
        )

        val  country = arrayOf(
            "India","China","Russia","Canada","Kenya","Bhutam","USA","UAE","Agile","USA","UAE","Agile"
        )

        userArrayList = ArrayList()
        for (i in name.indices) {
            val user =
                User(name[i], lastMessage[i], lastmsgTime[i], phoneNo[i], country[i], imageId[i])
            userArrayList.add(user)
        }


        binding.listview.isClickable = true
        binding.listview.adapter = MyAdapter(this,userArrayList)

        binding.listview.setOnItemClickListener { parent, view, position, id ->
            val name = name[position]
            val phone = phoneNo[position]
            val country = country[position]
            val imageId = imageId[position]


            val i = Intent(this, UserActivity::class.java)
            i.putExtra("name",name)
            i.putExtra("phone",phone)
            i.putExtra("coumtry",country)
            i.putExtra("imageId",imageId)
            startActivity(i)

        }
    }



}